"""SalesVision application configuration."""
